export interface ResumeAnalysis {
  skills: string[];
  experience: string[];
  education: string[];
  suggestedRole: string;
}

export interface InternshipRecommendation {
  company: string;
  title: string;
  description: string;
  justification: string;
  url: string;
}

export interface GroundingSource {
  web: {
    uri: string;
    title: string;
  };
}

export interface ChatMessage {
  sender: 'user' | 'bot';
  text: string;
}