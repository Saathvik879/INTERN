
import React, { useState, useCallback } from 'react';
import type { ResumeAnalysis, InternshipRecommendation, GroundingSource } from '../types';
import { analyzeResume, getInternshipRecommendations } from '../services/geminiService';
import ResumeProcessor from './ResumeProcessor';
import Recommendations from './Recommendations';
import Chatbot from './Chatbot';
import { BriefcaseIcon } from './icons';

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(',')[1]);
    };
    reader.onerror = error => reject(error);
  });
};


const HomePage: React.FC = () => {
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [location, setLocation] = useState<string>('');
  const [analysis, setAnalysis] = useState<ResumeAnalysis | null>(null);
  const [recommendations, setRecommendations] = useState<InternshipRecommendation[]>([]);
  const [sources, setSources] = useState<GroundingSource[]>([]);
  
  const [isLoadingAnalysis, setIsLoadingAnalysis] = useState<boolean>(false);
  const [isLoadingRecs, setIsLoadingRecs] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState<boolean>(false);

  const handleProcessResume = useCallback(async () => {
    if (!resumeFile || !location) {
      setError("Please upload your resume and provide a location before processing.");
      return;
    }
    
    setIsLoadingAnalysis(true);
    setIsLoadingRecs(true);
    setHasSearched(true);
    setError(null);
    setAnalysis(null);
    setRecommendations([]);
    setSources([]);

    try {
      const base64 = await fileToBase64(resumeFile);
      const analysisResult = await analyzeResume({ base64, mimeType: resumeFile.type });
      
      setAnalysis(analysisResult);
      setIsLoadingAnalysis(false);

      if (analysisResult) {
        const recsResult = await getInternshipRecommendations(analysisResult.suggestedRole, analysisResult.skills, location);
        if (recsResult) {
          setRecommendations(recsResult.recommendations);
          setSources(recsResult.sources);
        } else {
          setError("Could not fetch internship recommendations. Please try again.");
        }
      } else {
        setError("Could not analyze the resume. Please check the file and try again.");
      }
    } catch (e) {
      setError("An unexpected error occurred. Please try again later.");
      console.error(e);
    } finally {
      setIsLoadingAnalysis(false);
      setIsLoadingRecs(false);
    }
  }, [resumeFile, location]);


  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <BriefcaseIcon className="h-8 w-8 text-blue-600" />
            <span className="text-xl font-bold text-gray-800">AI Internship Advisor</span>
          </div>
        </nav>
      </header>

      <main className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          <ResumeProcessor
            resumeFile={resumeFile}
            setResumeFile={setResumeFile}
            location={location}
            setLocation={setLocation}
            onProcess={handleProcessResume}
            isLoading={isLoadingAnalysis}
            analysis={analysis}
            error={error}
          />
          <Recommendations
            recommendations={recommendations}
            sources={sources}
            isLoading={isLoadingRecs}
            hasSearched={hasSearched}
          />
        </div>
      </main>
      
      <Chatbot />
    </div>
  );
};

export default HomePage;
