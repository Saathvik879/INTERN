
import React from 'react';
import type { ResumeAnalysis } from '../types';
import { LightBulbIcon, BriefcaseIcon, GraduationCapIcon, DocumentArrowUpIcon, DocumentTextIcon, CloseIcon, MapPinIcon } from './icons';

interface ResumeProcessorProps {
  resumeFile: File | null;
  setResumeFile: (file: File | null) => void;
  location: string;
  setLocation: (location: string) => void;
  onProcess: () => void;
  isLoading: boolean;
  analysis: ResumeAnalysis | null;
  error: string | null;
}

const ResumeProcessor: React.FC<ResumeProcessorProps> = ({ resumeFile, setResumeFile, location, setLocation, onProcess, isLoading, analysis, error }) => {
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setResumeFile(e.target.files[0]);
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-2xl font-bold mb-4">1. Your Information</h2>
        
        <div>
          <label htmlFor="resume-upload" className="block text-sm font-medium text-gray-700 mb-1">Your Resume</label>
          <p className="text-gray-600 text-sm mb-3">Upload your resume in PDF format. Our AI will analyze it to find the best opportunities for you.</p>
          <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
            <div className="space-y-1 text-center">
              <DocumentArrowUpIcon className="mx-auto h-12 w-12 text-gray-400" />
              <div className="flex text-sm text-gray-600 justify-center">
                <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                  <span>Upload a file</span>
                  <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept=".pdf" disabled={isLoading}/>
                </label>
                <p className="pl-1">or drag and drop</p>
              </div>
              <p className="text-xs text-gray-500">PDF up to 10MB</p>
            </div>
          </div>
        </div>

        {resumeFile && !isLoading && (
          <div className="mt-4 border border-gray-200 rounded-md p-3 flex items-center justify-between">
            <div className="flex items-center min-w-0">
              <DocumentTextIcon className="w-6 h-6 text-gray-500 flex-shrink-0" />
              <span className="ml-3 text-sm font-medium text-gray-700 truncate">{resumeFile.name}</span>
            </div>
            <button onClick={() => setResumeFile(null)} className="text-gray-400 hover:text-gray-600 ml-2">
              <CloseIcon className="w-5 h-5" />
            </button>
          </div>
        )}

        <div className="mt-4">
            <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">Your Location</label>
            <p className="text-gray-600 text-sm mb-3">Enter your city or region to find internships near you.</p>
            <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <MapPinIcon className="h-5 w-5 text-blue-300" />
                </div>
                <input
                    type="text"
                    id="location"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="block w-full rounded-md border border-blue-500 bg-blue-700 text-white pl-10 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400 sm:text-sm placeholder-blue-300"
                    placeholder="e.g., San Francisco, CA"
                    disabled={isLoading}
                />
            </div>
        </div>


        <button
          onClick={onProcess}
          disabled={isLoading || !resumeFile || !location}
          className="mt-6 w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-md hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Analyzing...
            </>
          ) : (
            'Analyze & Find Internships'
          )}
        </button>
        {error && <p className="text-red-500 mt-4 text-sm">{error}</p>}
      </div>

      {isLoading && (
         <div className="bg-white p-6 rounded-lg shadow animate-pulse">
            <div className="h-6 bg-gray-200 rounded w-3/4 mb-4"></div>
            <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-5/6"></div>
         </div>
      )}

      {analysis && !isLoading && (
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-xl font-bold mb-4">Resume Analysis</h3>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold text-gray-700 flex items-center"><LightBulbIcon className="w-5 h-5 mr-2 text-blue-500"/>Suggested Role</h4>
              <p className="text-gray-600 bg-blue-50 p-3 rounded-md mt-1">{analysis.suggestedRole}</p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-700 flex items-center"><BriefcaseIcon className="w-5 h-5 mr-2 text-blue-500"/>Key Skills</h4>
              <div className="flex flex-wrap gap-2 mt-1">
                {analysis.skills.map((skill, index) => (
                  <span key={index} className="bg-gray-200 text-gray-800 text-xs font-medium px-2.5 py-1 rounded-full">{skill}</span>
                ))}
              </div>
            </div>
             <div>
              <h4 className="font-semibold text-gray-700 flex items-center"><GraduationCapIcon className="w-5 h-5 mr-2 text-blue-500"/>Education</h4>
              <ul className="list-disc list-inside text-gray-600 mt-1">
                {analysis.education.map((edu, index) => <li key={index}>{edu}</li>)}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResumeProcessor;