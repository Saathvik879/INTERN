import React from 'react';
import type { InternshipRecommendation, GroundingSource } from '../types';
import { BriefcaseIcon, CheckCircleIcon, ArrowTopRightOnSquareIcon } from './icons';

interface RecommendationsProps {
  recommendations: InternshipRecommendation[];
  sources: GroundingSource[];
  isLoading: boolean;
  hasSearched: boolean;
}

const RecommendationSkeleton: React.FC = () => (
    <div className="bg-white p-6 rounded-lg shadow animate-pulse">
        <div className="h-5 bg-gray-200 rounded w-3/5 mb-2"></div>
        <div className="h-4 bg-gray-200 rounded w-2/5 mb-4"></div>
        <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
        <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
        <div className="h-4 bg-gray-200 rounded w-5/6 mb-4"></div>
        <div className="h-4 bg-gray-200 rounded w-1/2"></div>
    </div>
)

const Recommendations: React.FC<RecommendationsProps> = ({ recommendations, sources, isLoading, hasSearched }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h2 className="text-2xl font-bold mb-4">2. Top Recommendations</h2>
      <div className="space-y-4">
        {isLoading && (
          <>
            <RecommendationSkeleton />
            <RecommendationSkeleton />
            <RecommendationSkeleton />
          </>
        )}
        {!isLoading && recommendations.length === 0 && (
          <>
            {hasSearched ? (
              <div className="text-center py-10 px-6 bg-yellow-50 rounded-lg border-2 border-dashed border-yellow-300">
                <BriefcaseIcon className="mx-auto h-12 w-12 text-yellow-500" />
                <h3 className="mt-4 text-lg font-medium text-gray-900">No Internships Found</h3>
                <p className="mt-2 text-sm text-gray-600">
                  We couldn't find internships matching your profile right now. New roles open up daily, so check back soon!
                </p>
              </div>
            ) : (
              <div className="text-center py-10 px-6 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
                <BriefcaseIcon className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-4 text-lg font-medium text-gray-900">Your Personalized Recommendations Await</h3>
                <p className="mt-2 text-sm text-gray-500">
                  After analyzing your resume, this space will highlight key takeaways and showcase the best internship opportunities for you.
                </p>
                <div className="mt-6 text-left text-sm text-gray-600 space-y-3 max-w-md mx-auto">
                    <p className="flex items-start"><CheckCircleIcon className="w-5 h-5 mr-2 text-green-500 flex-shrink-0 mt-0.5"/> Top 5 internship matches from leading platforms.</p>
                    <p className="flex items-start"><CheckCircleIcon className="w-5 h-5 mr-2 text-green-500 flex-shrink-0 mt-0.5"/> Detailed justifications on why each role fits your profile.</p>
                    <p className="flex items-start"><CheckCircleIcon className="w-5 h-5 mr-2 text-green-500 flex-shrink-0 mt-0.5"/> Verified web sources for every listing to apply directly.</p>
                </div>
              </div>
            )}
          </>
        )}
        {!isLoading && recommendations.length > 0 && (
            <>
                {recommendations.map((rec, index) => (
                    <div key={index} className="border border-gray-200 p-4 rounded-lg hover:shadow-md transition-shadow">
                        <div className="mb-2">
                            <h4 className="font-bold text-lg text-blue-700">{rec.title}</h4>
                            <p className="text-gray-600 font-medium">{rec.company}</p>
                        </div>
                        <p className="text-gray-700 text-sm mb-3">{rec.description}</p>
                        <div className="bg-green-50 border-l-4 border-green-500 text-green-800 p-3 rounded-r-lg mb-3">
                            <p className="font-semibold text-sm">Why it's a match:</p>
                            <p className="text-sm">{rec.justification}</p>
                        </div>
                        {rec.url && (
                            <a
                                href={rec.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-800 transition-colors"
                            >
                                View Application
                                <ArrowTopRightOnSquareIcon className="ml-1.5 h-4 w-4" />
                            </a>
                        )}
                    </div>
                ))}
                {sources.length > 0 && (
                    <div className="mt-6 pt-4 border-t border-gray-200">
                        <h3 className="text-sm font-semibold text-gray-600 mb-3">Sourced From:</h3>
                        <div className="flex flex-wrap gap-2">
                            {sources.map((source, index) => (
                                <a 
                                key={index} 
                                href={source.web.uri} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="bg-gray-100 text-gray-700 text-xs font-medium px-3 py-1.5 rounded-full hover:bg-gray-200 transition-colors flex items-center shadow-sm"
                                >
                                {source.web.title || new URL(source.web.uri).hostname}
                                <ArrowTopRightOnSquareIcon className="ml-1.5 h-3 w-3" />
                                </a>
                            ))}
                        </div>
                    </div>
                )}
            </>
        )}
      </div>
    </div>
  );
};

export default Recommendations;