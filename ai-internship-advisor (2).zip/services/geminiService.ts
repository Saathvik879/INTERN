
import { GoogleGenAI, Type, Chat, GenerateContentResponse } from "@google/genai";
import type { ResumeAnalysis, InternshipRecommendation, GroundingSource } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
let chatInstance: Chat | null = null;

export const analyzeResume = async (resumeData: { base64: string; mimeType: string }): Promise<ResumeAnalysis | null> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: resumeData.mimeType,
              data: resumeData.base64,
            },
          },
          {
            text: `Analyze the following resume document and extract key information. Based on the analysis, provide a concise, one-sentence summary for an ideal internship role.`
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            skills: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "List of key technical and soft skills."
            },
            experience: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "List of key experiences or projects, summarized."
            },
            education: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "List of educational qualifications."
            },
            suggestedRole: {
              type: Type.STRING,
              description: "A single, concise sentence describing the ideal internship role."
            }
          },
          required: ["skills", "experience", "education", "suggestedRole"]
        }
      }
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText);
  } catch (error) {
    console.error("Error analyzing resume:", error);
    return null;
  }
};


export const getInternshipRecommendations = async (
  jobRole: string,
  skills: string[],
  location: string
): Promise<{ recommendations: InternshipRecommendation[], sources: GroundingSource[] } | null> => {
  const prompt = `Based on the job role "${jobRole}", skills like "${skills.join(', ')}", and the location "${location}", find the top 5 currently available internships from various online platforms. Prioritize roles that are physically located in or near the specified location, or are explicitly listed as remote.
  
  Format your response as a valid JSON array of objects. Do not include any text, notes, or explanations outside of the JSON array itself. Each object in the array must represent one internship and have the following keys with string values: "company", "title", "description", "justification", and "url". The "url" must be the direct link to the internship application or details page.
  
  Example:
  [
    {
      "company": "Innovate Inc.",
      "title": "Data Science Intern",
      "description": "Work with our data team to build predictive models and analyze user behavior.",
      "justification": "This role is an excellent match due to your proficiency in Python and machine learning concepts mentioned in your projects.",
      "url": "https://careers.innovateinc.com/internships/data-science-intern"
    }
  ]`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const responseText = response.text.trim();
    let jsonStringToParse = responseText;

    // The model may return JSON within a markdown block. Let's extract it.
    const jsonMatch = responseText.match(/```(json)?\s*([\s\S]*?)\s*```/);
    if (jsonMatch && jsonMatch[2]) {
      jsonStringToParse = jsonMatch[2];
    }
    
    const recommendations = JSON.parse(jsonStringToParse) as InternshipRecommendation[];
    const sources = (response.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingSource[]) || [];

    return { recommendations, sources };
  } catch (error) {
    console.error("Error getting internship recommendations:", error);
    return null;
  }
};


export const getChatStream = async (message: string) => {
    if (!chatInstance) {
        chatInstance = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
                systemInstruction: "You are a friendly and professional career advisor chatbot. You help users with quick questions about their job search, resumes, and interviews. Keep your answers concise and helpful."
            }
        });
    }
    return await chatInstance.sendMessageStream({ message });
}
