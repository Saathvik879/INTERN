
import React, { useState } from 'react';
import LoginPage from './components/LoginPage';
import HomePage from './components/HomePage';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  if (!isAuthenticated) {
    return <LoginPage onLoginSuccess={() => setIsAuthenticated(true)} />;
  }

  return <HomePage />;
};

export default App;
